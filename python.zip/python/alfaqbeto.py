def nombres_alfabeto(nombre):
    sorted_name = sorted(nombre)
    return sorted_name


nombres= ["sanchez", "lara", "caseres", "jimenez"]
print(nombres_alfabeto(nombres))